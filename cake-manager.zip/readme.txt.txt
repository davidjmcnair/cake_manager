I set the context root to / instead of cake-manager.

I set index.jsp page on root to redirect to /cakes to match the servlet path, so localhost:8080 or localhost:8080/cakes both give the same list of cakes

In servlet doGet I checked the requestHeader to see if it was a browser request, if it is browser displays jsp page human readable page, otherwise the doGet returns Json.

I used a jsp to display the human readable cake list on screen, using jstl to remove java code. 

I added a servlet doPost method to add newCakes and a form to the jsp which calls the doPost method 
 
I added a service layer CakeService to return cakes list and add cakes instead of inclusing the code directly in servlet.

The JSON feed contains duplicate cakes, I removed these by keeping a list of the titles of cakes as they were added and checking 
in the list to see if a cake exists prior to creating cakes. If the feed was huge performace might be an issue so an altenrative might be required.

The CakeEntity class bizarrely maps to Employee table and fields not clear why this is but I have changed to table CAKE and appropriate fields.

To do: 
I didn't use any CSS to style/beautify the webpage, in a real application this would be required 
I didn't do any validation on Add cakes form to prevent duplicates or blank/invalid entries. 






