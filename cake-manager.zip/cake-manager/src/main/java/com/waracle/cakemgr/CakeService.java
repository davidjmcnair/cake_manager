package com.waracle.cakemgr;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

public class CakeService {
	public static List<CakeEntity> getCakes() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		List<CakeEntity> list = session.createCriteria(CakeEntity.class).list();
		return list;
	}

	public static void addCake(String title, String description, String imageUrl) {
		CakeEntity cakeEntity = new CakeEntity();
		cakeEntity.setTitle(title);
		cakeEntity.setDescription(description);
		cakeEntity.setImage(imageUrl);
		Session session = HibernateUtil.getSessionFactory().openSession();
		try {
			session.beginTransaction();
			session.persist(cakeEntity);
			System.out.println("adding cake entity");
			session.getTransaction().commit();
		} catch (ConstraintViolationException ex) {

		}
		session.close();
	}
}
